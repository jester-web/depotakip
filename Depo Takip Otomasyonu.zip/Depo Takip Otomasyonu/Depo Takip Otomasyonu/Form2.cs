﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Depo_Takip_Otomasyonu
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-9DNFSA5\SQLEXPRESS01;Initial Catalog=depoadmin;Integrated Security=True");
        private void Form2_Load(object sender, EventArgs e)
        {
            verigoster();
        }
        private void verigoster()
        {
            string data = "select * from stok";
            SqlDataAdapter da = new SqlDataAdapter(data, baglanti);

            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            try
            {
                baglanti.Open();
                SqlCommand sqlcommand = new SqlCommand("insert into stok (stokadi,stokmodeli,stokserino,stokadeti,kayityapan) values(@p1,@p2,@p3,@p4,@p5)", baglanti);
                sqlcommand.Parameters.AddWithValue("@p1", textBox1.Text);
                sqlcommand.Parameters.AddWithValue("@p2", textBox2.Text);
                sqlcommand.Parameters.AddWithValue("@p3", textBox3.Text);
                sqlcommand.Parameters.AddWithValue("@p4", Convert.ToInt16(textBox4.Text));
                sqlcommand.Parameters.AddWithValue("@p5", textBox5.Text);
                sqlcommand.ExecuteNonQuery();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("kayıt eklenemedi" + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }
            verigoster();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();
                SqlCommand sqlcommand = new SqlCommand("delete from stok where stokadi=@p1", baglanti);
                sqlcommand.Parameters.AddWithValue("@p1", textBox1.Text);
                sqlcommand.ExecuteNonQuery();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";

            }
            catch (Exception ex)
            {
                MessageBox.Show("kayıt eklenemedi" + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }
            verigoster();


        }

        private void button7_Click(object sender, EventArgs e)
        {
             try
            {
                baglanti.Open();
                SqlCommand sqlcommand = new SqlCommand("update stok set stokadi=@p1,stokmodeli=@p2,stokserino=@p3,stokadeti=@p4 where kayityapan=@p5 ", baglanti);
                sqlcommand.Parameters.AddWithValue("@p1", textBox1.Text);
                sqlcommand.Parameters.AddWithValue("@p2", textBox2.Text);
                sqlcommand.Parameters.AddWithValue("@p3", Convert.ToInt16(textBox3.Text));
                sqlcommand.Parameters.AddWithValue("@p4", textBox4.Text);
                sqlcommand.Parameters.AddWithValue("@p5", textBox5.Text);
                sqlcommand.ExecuteNonQuery();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
            }
             catch (Exception ex)
             {
                 MessageBox.Show("kayıt eklenemedi" + ex.Message);
             }
             finally
             {
                 baglanti.Close();
             }
             verigoster();


        }


        private void button3_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilensatir = dataGridView1.SelectedCells[0].RowIndex;
            textBox1.Text = dataGridView1.Rows[secilensatir].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[secilensatir].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.Rows[secilensatir].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.Rows[secilensatir].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.Rows[secilensatir].Cells[4].Value.ToString();
        }
    }
}