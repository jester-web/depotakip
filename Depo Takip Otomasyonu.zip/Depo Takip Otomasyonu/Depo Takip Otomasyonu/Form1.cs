﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Depo_Takip_Otomasyonu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-9DNFSA5\SQLEXPRESS01;Initial Catalog=depoadmin;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            string sifre = " ";
            try
            {
                baglanti.Open();
                SqlCommand Sqlkomut = new SqlCommand("Select sifre from admingiris where kullaniciadi = @p1", baglanti);
                Sqlkomut.Parameters.AddWithValue("@p1", textBox1.Text);
                SqlDataReader SqlDataReader = Sqlkomut.ExecuteReader();

                while (SqlDataReader.Read())
                {
                    sifre = SqlDataReader[0].ToString();
                }

                if (sifre == textBox2.Text)
                {
                    Form2 frm2 = new Form2();
                    frm2.Show();
                }
                else
                {
                    MessageBox.Show("Kullanıcı Adı Şifre Hatalı");
                    textBox1.Text = " ";
                    textBox2.Text = " ";
                }
            }


            catch (Exception ex)
            {
                MessageBox.Show("Bağlantı Hatası");
            }
        }
    }
}
