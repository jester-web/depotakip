﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Depo_Takip_Otomasyonu
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-9DNFSA5\SQLEXPRESS01;Initial Catalog=depoadmin;Integrated Security=True");
        private void btnStokModelAra_Click(object sender, EventArgs e)
        {
            string aranan = textBox6.Text.Trim().ToUpper();
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewCell cell in dataGridView1.Rows[i].Cells)
                    {
                        if (cell.Value != null)
                        {
                            if (cell.Value.ToString().ToUpper() == aranan)
                            {
                                cell.Style.BackColor = Color.CornflowerBlue;
                                break;
                            }
                        }
                    }
                }
            }
        }
                
     

        private void Form3_Load(object sender, EventArgs e)
        {
            verigoster();
        }
        private void verigoster()
        {
            string data = "select * from stok";
            SqlDataAdapter da = new SqlDataAdapter(data, baglanti);

            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
             Form2 frm2 = new Form2();
             frm2.Show();
        }
    }
}
